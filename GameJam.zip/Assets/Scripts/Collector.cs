﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collector : MonoBehaviour
{
    ManagerSC Manager;
    // Start is called before the first frame update
    void Start()
    {
        Manager = GameObject.Find("LandingPlatform").GetComponentInParent<ManagerSC>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnTriggerEnter()
    {
        Manager.AsteroidCollected += 1;
        Destroy(this.gameObject, 0.2f);
    }
}
