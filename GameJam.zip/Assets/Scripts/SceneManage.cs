﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneManage : MonoBehaviour {
    public GameObject PauseMenu;
    Scene ActiveScene;

	// Use this for initialization
	void Start () {
        ActiveScene = SceneManager.GetActiveScene();
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    public void LoadNextLevel()
    {
        SceneManager.LoadScene(ActiveScene.buildIndex+1);
    }
    public void Retry()
    {
        SceneManager.LoadScene(ActiveScene.buildIndex);
    }
    public void Pause()
    {
        Time.timeScale = 0f;
        PauseMenu.SetActive(true);
    }
}
