﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamMov : MonoBehaviour
{
    public GameObject player;
    //float camPos;
    public Vector3 offset;
    // Start is called before the first frame update
    void Start()
    {
       
        //camPos = cam.transform.position.z;
        
    }

    // Update is called once per frame
    void Update()
    {

        Vector3 newPos = player.transform.position+offset;
        
        //newPos.y = transform.position.y;
        transform.position = newPos;
    }
}
