﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cube : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetButtonDown("Jump"))
        {
            gameObject.transform.localScale = new Vector3(2, 2, 2);
        }
        if(Input.GetButtonUp("Jump"))
        {
           gameObject.transform.localScale = new Vector3(1, 1, 1);
        }
        if(Input.GetKey(KeyCode.UpArrow)&&(gameObject.tag==("cube2")))
        {
            gameObject.transform.Translate(Vector3.forward);
        }
        if (Input.GetKey(KeyCode.DownArrow) && (gameObject.tag == ("cube2")))
        {
            gameObject.transform.Translate(Vector3.back);
        }
        if(Input.GetKey(KeyCode.LeftArrow))
        {
            //gameObject.transform.rotation = Quaternion.EulerAngles(0, 1f, 0);
            gameObject.transform.Rotate(0, 1, 0);
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
           // gameObject.transform.rotation = Quaternion.EulerAngles(0, -1f, 0);
            gameObject.transform.Rotate(0, -1, 0);
        }
    }
        

    
}
