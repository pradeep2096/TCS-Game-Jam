﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class UI : MonoBehaviour {
   public Slider FuelMeter;
    public static bool Playerdead;
    public GameObject pausepanel;
    public GameObject gameoverpanel;
    public GameObject levelEndPanel;
    public GameObject onestar,twostar,threestar;
    int scene;
    public GameObject GAMEFINISHED;
    public GameObject info;
	// Use this for initialization
	void Start () {
        FuelMeter = GetComponentInChildren<Slider>();
        Playerdead = false;
        scene = SceneManager.GetActiveScene().buildIndex;
        Time.timeScale = 1f;
	}
	
	// Update is called once per frame
	void Update () {
		if(FuelMeter.value<=0f)
        {
            Playerdead = true;
            print("fuelover");
        }
        if(Playerdead)
        {
            PlayerDeath();
        }
        
        
	}
    public void PlayerDeath()
    {
        gameoverpanel.SetActive(true);
        Time.timeScale = 0f;
    }
    public void infofunc()
    {
        info.SetActive(true);
    }
    public void Back()
    {
        info.SetActive(false);
    }
    public void Pause()
    {
        Time.timeScale = 0f;
        pausepanel.SetActive(true);
    }
    public void Retry()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        
    }
    public void Endgame()
    {
        
        Application.Quit();
    }
    public void PlayStart()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(1);
    }
    public void Resume()
    {
        Time.timeScale = 1f;
        pausepanel.SetActive(false);
    }
    public void LevelEnd()
    {
        levelEndPanel.SetActive(true);
        checkForStars();
        if (scene == 8)
        {
            GAMEFINISHED.SetActive(true);
        }
    }
    public void NextLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex+1);
        Time.timeScale = 1f;
    }
    public void checkForStars()
    {
        if(FuelMeter.value<0.33f)
        {
            onestar.SetActive(true);

        }
        else if(FuelMeter.value<0.66f)
        {
            twostar.SetActive(true);
        }
        else
        {
            threestar.SetActive(true);
        }
    }
}
