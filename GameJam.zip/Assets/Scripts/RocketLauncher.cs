﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class RocketLauncher : MonoBehaviour {
    Rigidbody rb;
    public float speed;
    AudioSource Audi;
    [SerializeField]
    float Rspeed;
    public GameObject ThrustFX;
    
    UI ui;
    public GameObject BlastAnim;
    
    bool inAir;
    
    float t2;
    [Header("Fuel Reduce Speed")]
    public float t;
    // Use this for initialization
    void Start () {
        rb = GetComponent<Rigidbody>();
        Audi = GetComponent<AudioSource>();
        Time.timeScale = 1f;
        
        ui = GameObject.Find("Canvas").GetComponent<UI>();
        t2 = t;
	}
    private void OnCollisionExit(Collision collision)
    {
        inAir = true;
    }
    private void OnCollisionStay(Collision collision)
    {
        inAir = false;
    }
    // Update is called once per frame
    void Update () 
    {
        Thrust();
        if(inAir)
        {
            Rotation();
        }
        DeathbyFall();
    }
    void  Thrust()
    {
        if (Input.GetKey(KeyCode.W))
        {
            ThrustFX.SetActive(true);
            rb.AddRelativeForce(Vector3.up * speed*Time.deltaTime);
            if (!Audi.isPlaying)
            {
                Audi.Play();
            }
            if(t2<=0)// this will ensure that slider value(fuel meter isnt reduced every frame , rather executes function every time(t) seconds)
            {
                ui.FuelMeter.value -= 0.01f;
                t2 = t;
            }
            else if(t>0)
            {
                t2-= Time.deltaTime;
            }
            
        }
        else
        {
            Audi.Stop();
            ThrustFX.SetActive(false);
        }
    }
    void Rotation()
    {
        
        float RS = Input.GetAxis("Horizontal");
        transform.Rotate(new Vector3(0, 0, -RS)*Rspeed*Time.deltaTime);
        
    }
    void DeathbyFall()
    {
        if(transform.position.y<-1.5f)
        {
            print("You Ded");
            UI.Playerdead = true;
        }
        
    }
    
    
}
