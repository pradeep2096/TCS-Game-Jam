﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ThrowBomb : MonoBehaviour {
    public float ThrowForce;
    public GameObject Bomb;
    public static bool clicked = false;


	// Use this for initialization
	void Start () {
        
		
	}
	
	// Update is called once per frame
	void Update () {

        if(Input.GetMouseButton(0))
        {
            ThrowTheBomb();
            clicked = true;
        }
		
	}
    void ThrowTheBomb()
    {
        
        Rigidbody Bombrb = Bomb.GetComponent<Rigidbody>();
        Bombrb.useGravity = true;
        Bombrb.AddForce(transform.forward * ThrowForce);
        
    }
}
