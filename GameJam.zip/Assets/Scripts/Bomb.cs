﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bomb : MonoBehaviour {
    public float delay=3f;
    float countdown;
    bool explode;
    public GameObject Explosion;
    float radius = 8f;

	// Use this for initialization
	void Start () {
        countdown = delay;
        explode = false;
		
	}
	
	// Update is called once per frame
	void Update () {
        
        if(!explode&&ThrowBomb.clicked)
        {
            //countdown -= Time.deltaTime;
            StartCoroutine(wait());
            
            explode = true;
            
        }
		
	}
    void Explode()
    {
        Debug.Log("BOOM GOES THE DYNAMITE");
        Instantiate(Explosion, transform.position, transform.rotation);
       Collider[] colliders= Physics.OverlapSphere(transform.position, radius);
        foreach (Collider nearbox in colliders)
        {
            Rigidbody rb = nearbox.GetComponent<Rigidbody>();
            if(rb!=null)
            {
                rb.AddExplosionForce(1000f, transform.position, radius);
            }
        }
        AudioSource audi = GameObject.Find("CUBES").GetComponent<AudioSource>();
        audi.Play();
        Destroy(gameObject);
    }
    IEnumerator wait()
    {
        yield return new WaitForSeconds(2f);
        Explode();
    }
}
