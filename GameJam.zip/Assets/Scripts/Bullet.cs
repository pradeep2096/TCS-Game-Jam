﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour {
    public GameObject Player;
    Rigidbody rb;
    public float Bulletspeed;
    public Transform bullet;

	// Use this for initialization
	void Start () {
         rb = bullet.GetComponent<Rigidbody>();
		
	}
	
	// Update is called once per frame
	void Update () {
        if(Input.GetKeyUp(KeyCode.RightControl))
        {
            Instantiate(bullet, Player.transform.position, Player.transform.rotation);
            rb.AddRelativeForce(Vector3.up * Bulletspeed * Time.deltaTime);
        }
        
	}
}
