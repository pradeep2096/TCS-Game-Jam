﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManagerSC : MonoBehaviour
{
    public int AsteroidCollected=0;
    public int allAsteroids;
    UI ui;
    // Start is called before the first frame update
    void Start()
    {
        ui = GameObject.Find("Canvas").GetComponent<UI>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void SceneComplete()
    {
        print("SceneCompleted");
        ui.LevelEnd();
    }
    
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag=="Player")
        {
            if (AsteroidCollected >= allAsteroids)
            {
                SceneComplete();
            }
        }
    }
}
